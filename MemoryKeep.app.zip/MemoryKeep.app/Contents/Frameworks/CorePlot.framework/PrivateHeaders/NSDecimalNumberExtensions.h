/** @category NSDecimalNumber(CPTExtensions)
 *  @brief Core Plot extensions to NSDecimalNumber.
 **/
@interface NSDecimalNumber(CPTExtensions)

@end
