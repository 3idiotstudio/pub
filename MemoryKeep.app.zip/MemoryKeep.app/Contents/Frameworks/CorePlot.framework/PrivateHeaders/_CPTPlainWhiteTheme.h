#import "_CPTXYTheme.h"

@interface _CPTPlainWhiteTheme : _CPTXYTheme

@end
