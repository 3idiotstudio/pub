#import "_CPTXYTheme.h"

@interface _CPTPlainBlackTheme : _CPTXYTheme

@end
