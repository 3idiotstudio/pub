#import "CPTAxisLabel.h"

@interface CPTAxisTitle : CPTAxisLabel

@end
